using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Newtonsoft.Json;

namespace Assignment_3.Pages;

public class ReviewsModel : PageModel
{
    public List<Books> reviews { get; set; }

    private readonly ILogger<ReviewsModel> _logger;

    public ReviewsModel(ILogger<ReviewsModel> logger)
    {
        _logger = logger;
    }

    public void OnGet(Books books)
    {
        //assign deserialized json list
        this.reviews = loadbookReviews();
    }
    public List<Books> loadbookReviews(){
        //If file exists
        if(System.IO.File.Exists("Pages/reviews.json")){
            //Read json data and desearialize list
            var bookJson = System.IO.File.ReadAllText("Pages/reviews.json");
            //Null reference check
            return JsonConvert.DeserializeObject<List<Books>>(bookJson!) ?? new List<Books>();;
        }

        //Else return a new empty list
        return new List<Books>();
    }
}

