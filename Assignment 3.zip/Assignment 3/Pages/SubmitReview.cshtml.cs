using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Newtonsoft.Json;

namespace Assignment_3.Pages;

public class SubReview : PageModel
{
    public Books books = new Books();
    private readonly ILogger<SubReview> _logger;

    public SubReview(ILogger<SubReview> logger)
    {
        _logger = logger;
    }

    public void OnGet()
    {
        
    }
    public IActionResult OnPost(Books books){
        //get reviews list (empty or has data)
        var reviews = bookReviews();
        //Add review to List
        reviews.Add(books);
        //Serialize new review
        var jsonReview = JsonConvert.SerializeObject(reviews);
        //Save Review to file
        System.IO.File.WriteAllText("Pages/reviews.json", jsonReview);
        return RedirectToPage("Reviews", books);
    }

    public List<Books> bookReviews(){
        //If file exists
        if(System.IO.File.Exists("Pages/reviews.json")){
            //Read json data and desearialize list
            var jsonReview = System.IO.File.ReadAllText("Pages/reviews.json");
            //Null reference check
            return JsonConvert.DeserializeObject<List<Books>>(jsonReview!) ?? new List<Books>();;
        }

        //Else return a new empty list
        return new List<Books>();
    }
}
