public class Reviewers {
   public string reviewerName {get;set;}
public string  reviewersEmail {get;set;}
public string review {get;set;}
public int rating {get;set;}
}