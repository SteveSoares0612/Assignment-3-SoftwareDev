public class Books : Reviewers {
     public string bookTitle {get;set;}
    public string author {get;set;}
    public string datePublished {get;set;}
    public string genre {get;set;}
}